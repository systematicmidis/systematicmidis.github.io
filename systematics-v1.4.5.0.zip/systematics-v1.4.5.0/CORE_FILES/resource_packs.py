"""Resource pack support for Systematics TRILLION MIDI maker.

A "resource pack" is a folder placed inside the ``Resource Packs``
directory (next to the app, i.e. next to ``trillion.py`` in source mode or
next to the EXE in frozen mode). Each pack folder contains a ``CONFIG.yaml``
file plus optional PNG textures sitting next to it:

    Resource Packs/
      My Pack/
        CONFIG.yaml
        start.png            <- dark-mode icon override
        stop.png
        ...
        light/
          start.png          <- light-mode icon overrides (optional)

A pack folder may carry either a readable ``CONFIG.yaml`` or an encoded
``CONFIG.smcs`` (the app-only format: base64 gibberish with a checksum, so
only the app can read or change it — the editor writes these). ``CONFIG.smcs``
is preferred when both exist. Besides the palette and icons, a pack may
override the app-wide font (``font:``) and widget sizing (``sizing:`` —
button padding, button text ratio, sidebar width, tile size).

The ``CONFIG.yaml`` file may override the app palette per theme:

    name: My Pack
    description: Cool icons and colors
    palette:
      dark:
        ACCENT: "#ff8800"
        SIDEBAR: "#111111"
      light:
        ACCENT: "#0055cc"

Palette keys match the ones in ``app.PALETTES`` (ACCENT, MAIN_BG, TEXT, ...).
A flat ``palette:`` section (no ``dark``/``light`` nesting) applies to both
themes. Icon textures are just PNGs with the same names as the built-in
assets (start.png, stop.png, gears.png, document.png, ...); light-mode
variants live in a ``light/`` subfolder. A pack may also ship its own
``icon.ico`` / ``icon.png`` to replace the window / taskbar icon.

This module parses a tiny YAML subset on purpose (``key: value`` scalars and
indentation-nested dicts) so the app keeps its zero-dependency promise —
there is no ``import yaml`` anywhere.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import itertools
import json
import os
import re
import sys
import urllib.request
import zipfile

from . import __version__
from . import updater

CONFIG_NAME = "CONFIG.yaml"
CONFIG_SMCS = "CONFIG.smcs"

# --------------------------------------------------------------------------
# .SMCS — the app-only encoded config format
# --------------------------------------------------------------------------
# ``CONFIG.smcs`` holds the same config as CONFIG.yaml but ENCODED (XOR +
# base64 with an HMAC checksum), so only the app can read/write the contents:
# a user opening it in Notepad sees base64 gibberish, and any manual edit
# breaks the checksum, which the app detects and refuses to load. The editor
# saves packs as CONFIG.smcs; plain CONFIG.yaml remains supported for packs
# shared by hand (the app reads .smcs first when both exist).

_SMCS_MAGIC = b"SMCS1"
_SMCS_OBF = "AAAAAAAAAAAGBApGGBg="
_SMCS_KEY = b"ST-SMCS-Key-5!"
_SMCS_MASK = b"ST-SMCS-Mask-9?"


def _smcs_key() -> bytes:
    """Decode the obfuscated SMCS encoding key."""
    try:
        raw = base64.b64decode(_SMCS_OBF.encode("ascii"))
        return bytes(a ^ b for a, b in zip(raw, itertools.cycle(_SMCS_MASK)))
    except Exception:
        return _SMCS_KEY


def encode_smcs(cfg: dict) -> str:
    """Encode a config dict as an .SMCS string (magic + HMAC + XOR/base64)."""
    payload = json.dumps(cfg, ensure_ascii=False).encode("utf-8")
    key = _smcs_key()
    body = base64.b64encode(bytes(
        a ^ b for a, b in zip(payload, itertools.cycle(key)))).decode("ascii")
    checksum = hmac.new(key, body.encode("ascii"),
                        hashlib.sha256).hexdigest()[:16]
    return _SMCS_MAGIC.decode("ascii") + ":" + checksum + ":" + body


def decode_smcs(text: str) -> dict:
    """Decode an .SMCS string back into a config dict.

    Raises :class:`ValueError` when the magic is wrong or the checksum does
    not match (corrupt or hand-edited file)."""
    text = (text or "").strip()
    prefix = _SMCS_MAGIC.decode("ascii") + ":"
    if not text.startswith(prefix):
        raise ValueError("Not an SMCS file.")
    _, checksum, body = text.split(":", 2)
    key = _smcs_key()
    actual = hmac.new(key, body.encode("ascii"),
                      hashlib.sha256).hexdigest()[:16]
    if not hmac.compare_digest(checksum.strip().lower(), actual):
        raise ValueError("SMCS checksum mismatch - the file was modified.")
    try:
        raw = base64.b64decode(body)
        payload = bytes(a ^ b for a, b in zip(raw, itertools.cycle(key)))
        cfg = json.loads(payload.decode("utf-8"))
    except Exception as exc:
        raise ValueError(f"SMCS payload is corrupt: {exc}")
    if not isinstance(cfg, dict):
        raise ValueError("SMCS payload is not a config dict.")
    return cfg


# --------------------------------------------------------------------------
# .SMRP — Systematic Midis Resource Pack (pack archive format)
# --------------------------------------------------------------------------
# A resource pack can be shared/imported as a single file in two formats:
#
#   .zip   — a plain zip of the pack folder (CONFIG.yaml + textures + fonts)
#   .smrp  — the app's own archive: a zip whose FIRST member is ``smrp.meta``,
#            a tiny JSON holding the format marker and an HMAC checksum of
#            every other member. The app verifies the checksum on import, so
#            a hand-edited / corrupt / tampered SMRP is refused (same idea as
#            CONFIG.smcs). Because it is a zip under the hood, it can hold
#            the whole pack: config, icons, fonts, anything.

SMRP_MAGIC = b"SMRP1"
SMRP_META_NAME = "smrp.meta"
_SMRP_OBF = "AC1eJyg/MVkiBlRgV1I="
_SMRP_KEY = b"ST-SMRP-Key-6!"
_SMRP_MASK = b"Systematic-Mask-4#"
SMRP_EXT = ".smrp"
PACK_ARCHIVE_EXTS = (".zip", SMRP_EXT)


def _smrp_key() -> bytes:
    """Decode the obfuscated SMRP signing key."""
    try:
        raw = base64.b64decode(_SMRP_OBF.encode("ascii"))
        return bytes(a ^ b for a, b in zip(raw, itertools.cycle(_SMRP_MASK)))
    except Exception:
        return _SMRP_KEY


def create_smrp(pack: str, out_path: str) -> str:
    """Package an installed pack folder into a ``.SMRP`` archive.

    The archive is a zip whose first member is ``smrp.meta`` (format marker +
    HMAC of every other member), followed by the pack's files. Returns
    ``out_path``. Raises :class:`ValueError` if the pack isn't installed.
    """
    folder = pack_folder(pack)
    if not folder:
        raise ValueError(
            f"Pack {pack!r} is not installed, so it can't be exported.")
    members = []
    for dirpath, _dirnames, filenames in os.walk(folder):
        for fn in sorted(filenames):
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, folder).replace("\\", "/")
            members.append((rel, full))
    members.sort(key=lambda m: m[0])

    key = _smrp_key()
    h = hmac.new(key, digestmod=hashlib.sha256)
    # Members are stored under ``<pack>/`` so the folder name round-trips
    # through import (install_pack_zip derives it from the CONFIG parent).
    arcnames = {}
    for rel, full in members:
        arcname = pack + "/" + rel
        arcnames[rel] = arcname
        with open(full, "rb") as f:
            data = f.read()
        h.update(arcname.encode("utf-8"))
        h.update(b"\x00")
        h.update(data)
    meta = {"format": "SMRP", "version": 1, "pack": pack,
            "hmac": h.hexdigest()[:16]}

    out_dir = os.path.dirname(os.path.abspath(out_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(SMRP_META_NAME, json.dumps(meta))
        for rel, full in members:
            zf.write(full, arcname=arcnames[rel])
    return out_path


def _verify_smrp(path: str) -> None:
    """Validate an .SMRP archive (format marker + HMAC checksum). Raises
    :class:`ValueError` when the file isn't a genuine, unmodified SMRP."""
    with zipfile.ZipFile(path) as zf:
        names = [n.replace("\\", "/") for n in zf.namelist()]
        if SMRP_META_NAME not in names:
            raise ValueError("Not a valid SMRP file (missing smrp.meta).")
        try:
            meta = json.loads(zf.read(SMRP_META_NAME).decode("utf-8"))
        except Exception as exc:
            raise ValueError(f"smrp.meta is corrupt: {exc}")
    if meta.get("format") != "SMRP":
        raise ValueError("Not a valid SMRP file (bad format marker).")
    key = _smrp_key()
    h = hmac.new(key, digestmod=hashlib.sha256)
    for name in sorted(n for n in names if n != SMRP_META_NAME):
        with zipfile.ZipFile(path) as zf:
            data = zf.read(name)
        h.update(name.encode("utf-8"))
        h.update(b"\x00")
        h.update(data)
    expected = str(meta.get("hmac", "")).strip().lower()
    if not expected or not hmac.compare_digest(expected, h.hexdigest()[:16]):
        raise ValueError(
            "SMRP checksum mismatch — the file was modified or tampered with.")


def import_pack_file(path: str) -> str:
    """Import a resource pack archive (``.zip`` or ``.SMRP``) into the
    ``Resource Packs`` folder.

    Returns the folder name of the installed pack. Raises :class:`ValueError`
    for unsupported extensions, corrupt files, or a tampered SMRP.
    """
    if not os.path.isfile(path):
        raise ValueError("The pack file is missing.")
    ext = os.path.splitext(path)[1].lower()
    if ext not in PACK_ARCHIVE_EXTS:
        raise ValueError(
            "Only .zip and .smrp resource pack files are supported.")
    try:
        with zipfile.ZipFile(path) as zf:
            names = [n.replace("\\", "/") for n in zf.namelist()]
    except zipfile.BadZipFile as exc:
        raise ValueError(f"The file is not a valid zip: {exc}")
    if SMRP_META_NAME in names:
        _verify_smrp(path)
    return install_pack_zip(path)


# The pack repository index. Editing this points the in-app downloader at a
# hosted ``packs.json`` manifest whose entries list every available pack with
# a download URL. The URL is stored obfuscated (XOR + base64, same trick as
# the feed URL in updater.py).
_PACKS_INDEX_OBF = "OyBZIBJZRFxeMhYNSF5CJz1OPQgHAgADLAwNRUZBfT1CfxECCBheZQ8KQl0="
_PACKS_INDEX_KEY = b"ST-Packs-Key-3#"


def _decode_packs_index_url() -> str:
    """Decode the obfuscated pack-repo index URL."""
    raw = base64.b64decode(_PACKS_INDEX_OBF.encode("ascii"))
    return bytes(a ^ b for a, b in zip(raw, itertools.cycle(_PACKS_INDEX_KEY))).decode()


PACKS_INDEX_URL = _decode_packs_index_url()

# Named pack repositories offered in the download window's dropdown. Each
# entry is (display name, packs.json URL). The first entry is the official
# repository; add more tuples here to offer additional community repos in the
# app's "Get more packs…" menu.
PACK_REPOS = (
    ("Official (SystematicMidis)", PACKS_INDEX_URL),
)

# The built-in "Default" resource pack. It is hard-coded into the app (not a
# folder on disk) so the default look is always listed, verified, and its
# version always matches the app version. The Default pack ships no palette
# overrides and no icon textures — it is literally the app's stock look.
DEFAULT_PACK = "Default"
DEFAULT_PACK_AUTHOR = "Systematic"
DEFAULT_PACK_DESC = "The built-in look. Restores the default icons and colors."

# The palette keys the app actually uses (matches app.PALETTES entries).
PALETTE_KEYS = (
    "SIDEBAR", "SIDEBAR_HEADER", "NAV_ACTIVE", "MAIN_BG", "TILE",
    "TILE_HOVER", "TILE_DISABLED", "TILE_BORDER", "CARD", "CARD_BORDER",
    "ACCENT", "ACCENT_HOVER", "TEXT", "TEXT_MUTED", "FIELD",
    "BUTTON_SECONDARY", "BUTTON_SECONDARY_HOVER", "ACCENT_ON", "NEWS_BG",
)

# Widget sizing knobs a pack can override via a ``sizing:`` section in its
# CONFIG (or CONFIG.smcs). All values are numbers; ``button_font`` is a ratio
# (1.0 = follow the app's font scale, 1.2 = 20%% larger button text). The app
# applies these app-wide when the pack is active.
SIZING_DEFAULTS = {
    "button_padx": 16,    # interior horizontal padding of every button
    "button_pady": 8,     # interior vertical padding of every button
    "button_font": 1.0,   # button text size ratio
    "sidebar_width": 220, # open sidebar width in px
    "tile_size": 104,     # start/stop/tiles edge length in px
}
SIZING_KEYS = tuple(SIZING_DEFAULTS)

# Every icon the app uses. A complete pack ships a PNG for each of these
# (dark set at the pack root) plus the ``icon.ico`` / ``icon.png`` window
# icons. ``ICON_NAMES`` are the in-app buttons/controls; ``INFRA_ICONS`` are
# the window/taskbar icons that sit alongside them.
ICON_NAMES = (
    "start", "stop", "gears", "gears_small", "document", "document_card",
    "hamburger", "reload", "question", "info", "news",
)
INFRA_ICONS = ("icon.ico", "icon.png")

# --------------------------------------------------------------------------
# Signatures (“Verified” badge)
# --------------------------------------------------------------------------
# A pack is “Verified” when its ``signature:`` value matches the HMAC-SHA256
# of its name/version/author/description computed with the app's signing key
# (stored obfuscated below, the same way access.py hides the server URL).
# Only the app author knows the key, so a pack can only show “Verified” if it
# was signed by them. To sign your own pack, run:
#     python -m CORE_FILES.resource_packs --sign-full "Name" 1.0 "Author" "Desc"

_SIGN_OBF = "PzNaPh5JUTJGLwYkVUoiHVNcVQsqBgcYBwYDCSYTABhkRU1HTkxGNRI/hA=="
_SIGN_KEY = b"ST-Pack-Sign-Key-9!"


def _signing_key() -> bytes:
    """Decode the obfuscated signing key."""
    try:
        raw = base64.b64decode(_SIGN_OBF.encode("ascii"))
        return bytes(a ^ b for a, b in zip(raw, itertools.cycle(_SIGN_KEY)))
    except Exception:
        return _SIGN_KEY


def compute_signature(name, version, author, description) -> str:
    """Return the hex HMAC-SHA256 signature for a pack's metadata."""
    meta = "\n".join((str(name or ""), str(version or ""),
                       str(author or ""), str(description or "")))
    return hmac.new(_signing_key(), meta.encode("utf-8"),
                    hashlib.sha256).hexdigest()


def sign_is_valid(cfg: dict) -> bool:
    """True when cfg's ``signature`` equals the metadata signature."""
    return signature_state(cfg) == "valid"


def signature_state(cfg: dict) -> str:
    """Classify a pack's signature:

    - ``"valid"`` — ``signature`` present and matches the metadata.
    - ``"fake"`` — a ``signature`` is present but does NOT match (forged /
      tampered metadata, or signed with the wrong key).
    - ``"none"`` — no ``signature`` field at all (simply unsigned).
    """
    sig = cfg.get("signature")
    if not isinstance(sig, str) or not sig.strip():
        return "none"
    expected = compute_signature(cfg.get("name"), cfg.get("version"),
                                 cfg.get("author"), cfg.get("description"))
    try:
        return "valid" if hmac.compare_digest(sig.strip().lower(), expected) \
            else "fake"
    except Exception:
        return "fake"


# --------------------------------------------------------------------------
# Locating packs
# --------------------------------------------------------------------------

def app_root() -> str:
    """The folder the app lives in (next to the EXE when frozen)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def packs_dir() -> str:
    """The ``Resource Packs`` folder (created on demand by callers)."""
    return os.path.join(app_root(), "Resource Packs")


def is_default(pack: str) -> bool:
    """True when ``pack`` refers to the built-in Default pack."""
    return (pack or "") == DEFAULT_PACK


def _has_config(folder: str) -> bool:
    """True when ``folder`` holds a CONFIG.yaml or a CONFIG.smcs."""
    return os.path.isfile(os.path.join(folder, CONFIG_NAME)) or \
        os.path.isfile(os.path.join(folder, CONFIG_SMCS))


def list_packs() -> list:
    """Every selectable pack. The built-in Default pack is always first,
    followed by every folder under Resource Packs that has a config file
    (CONFIG.yaml or CONFIG.smcs)."""
    packs = [DEFAULT_PACK]
    base = packs_dir()
    if os.path.isdir(base):
        for name in sorted(os.listdir(base)):
            folder = os.path.join(base, name)
            if name == DEFAULT_PACK:
                continue
            if os.path.isdir(folder) and _has_config(folder):
                packs.append(name)
    return packs


def pack_folder(pack: str) -> str:
    """Absolute folder for a pack name ('' means no folder: the built-in
    look, or a named pack that isn't present on disk)."""
    if not pack or is_default(pack):
        return ""
    folder = os.path.join(packs_dir(), pack)
    if os.path.isdir(folder) and _has_config(folder):
        return folder
    return ""


# --------------------------------------------------------------------------
# Tiny YAML-subset parser (stdlib only)
# --------------------------------------------------------------------------

def _parse_scalar(text: str):
    value = text.strip()
    if not value:
        return ""
    if value.startswith("#") and len(value) == 7:
        return value  # hex color
    if (value.startswith('"') and value.endswith('"')) or \
            (value.startswith("'") and value.endswith("'")):
        return value[1:-1]
    low = value.lower()
    if low == "true":
        return True
    if low == "false":
        return False
    try:
        # Long all-digit strings (like a fake signature of all zeros) must
        # stay strings — converting them to int breaks signature checks.
        if re.fullmatch(r"-?\d{1,15}", value):
            return int(value)
        if re.fullmatch(r"-?\d+\.\d+", value):
            return float(value)
    except ValueError:
        pass
    return value


def _parse_yaml(text: str) -> dict:
    """Parse the minimal YAML subset used by CONFIG.yaml.

    Supports comments (``#``), ``key: value`` scalars, and indentation-nested
    dicts (2 or 4 spaces). Lists and inline arrays are not supported — if a
    line can't be parsed it is skipped rather than raising.
    """
    root: dict = {}
    stack: list[tuple[int, dict]] = [(-1, root)]  # (indent, dict)
    for raw in text.splitlines():
        # Strip comments: a '#' starts a comment only at the start of a line
        # or when preceded by whitespace. Quoted colors like "#ff8800" are
        # untouched because the '#' sits right after a quote.
        line = raw.rstrip()
        for i, ch in enumerate(line):
            if ch == "#" and (i == 0 or line[i - 1] in " \t"):
                line = line[:i]
                break
        line = line.rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()
        if ":" not in stripped:
            continue
        key, _, value = stripped.partition(":")
        key = key.strip()
        if not key:
            continue
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1] if stack else root
        if value.strip() == "":
            child: dict = {}
            parent[key] = child
            stack.append((indent, child))
        else:
            parent[key] = _parse_scalar(value)
    return root


# --------------------------------------------------------------------------
# Config access
# --------------------------------------------------------------------------

def load_config(pack: str) -> dict:
    """Read a pack's config. ``CONFIG.smcs`` is preferred when present (the
    encoded app-only format); otherwise ``CONFIG.yaml`` is parsed. Returns {}
    when the pack is invalid or a .smcs fails its checksum (tampered)."""
    folder = pack_folder(pack)
    if not folder:
        return {}
    smcs = os.path.join(folder, CONFIG_SMCS)
    if os.path.isfile(smcs):
        try:
            with open(smcs, "r", encoding="utf-8-sig") as f:
                return decode_smcs(f.read())
        except (OSError, ValueError):
            return {}
    try:
        with open(os.path.join(folder, CONFIG_NAME), "r",
                  encoding="utf-8-sig") as f:
            return _parse_yaml(f.read())
    except OSError:
        return {}


def smcs_path(pack: str) -> str:
    """Path to a pack's CONFIG.smcs ('' when the pack has no folder)."""
    folder = pack_folder(pack)
    if not folder:
        return ""
    return os.path.join(folder, CONFIG_SMCS)


def save_config(pack: str, cfg: dict) -> str:
    """Write ``cfg`` as an encoded CONFIG.smcs inside the pack's folder
    (creating the folder if needed). Returns the written path."""
    folder = os.path.join(packs_dir(), pack)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, CONFIG_SMCS)
    with open(path, "w", encoding="utf-8") as f:
        f.write(encode_smcs(cfg))
    return path


def _yaml_scalar(value) -> str:
    """Render one scalar for the readable YAML writer."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    text = str(value)
    if not text:
        return '""'
    if text[0] in "#\"'" or any(ch in text for ch in ":#{}[]&*!|>%@`\n"):
        return '"' + text.replace('"', '\\"') + '"'
    return text


def write_config_yaml(pack: str, cfg: dict) -> str:
    """Write ``cfg`` as a readable CONFIG.yaml (for inspection/export)."""
    folder = os.path.join(packs_dir(), pack)
    os.makedirs(folder, exist_ok=True)
    lines = []
    for key, value in cfg.items():
        if isinstance(value, dict):
            lines.append(f"{key}:")
            for k2, v2 in value.items():
                if isinstance(v2, dict):
                    lines.append(f"  {k2}:")
                    for k3, v3 in v2.items():
                        lines.append(f"    {k3}: {_yaml_scalar(v3)}")
                else:
                    lines.append(f"  {k2}: {_yaml_scalar(v2)}")
        else:
            lines.append(f"{key}: {_yaml_scalar(value)}")
    path = os.path.join(folder, CONFIG_NAME)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return path


def sizing_overrides(pack: str) -> dict:
    """Return the numeric ``sizing:`` values a pack requests. Only keys in
    :data:`SIZING_KEYS` with a positive number are returned; the built-in
    Default pack always returns {} (stock sizing)."""
    if not pack or is_default(pack):
        return {}
    sizing = load_config(pack).get("sizing")
    if not isinstance(sizing, dict):
        return {}
    overrides = {}
    for key in SIZING_KEYS:
        value = sizing.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if key == "button_font":
                if value > 0:
                    overrides[key] = float(value)
            elif value > 0:
                overrides[key] = int(value)
    return overrides


def pack_name(pack: str) -> str:
    """Human-readable name from CONFIG.yaml (falls back to the folder name)."""
    cfg = load_config(pack)
    name = cfg.get("name")
    if isinstance(name, str) and name.strip():
        return name.strip()
    return pack


def pack_metadata(pack: str) -> dict:
    """Return a display-ready dict for a pack: folder (unique on-disk name),
    name (CONFIG name, may be shared), version, author, description,
    verified (bool), complete (bool)."""
    if is_default(pack):
        # The built-in Default pack: always verified, always complete, and
        # its version tracks the app version. Its signature is recomputed on
        # the fly so it stays valid as the app is updated.
        return {
            "folder": DEFAULT_PACK,
            "name": DEFAULT_PACK,
            "version": str(__version__),
            "author": DEFAULT_PACK_AUTHOR,
            "description": DEFAULT_PACK_DESC,
            "verified": True,
            "sign_state": "valid",
            "complete": True,
        }
    cfg = load_config(pack)
    name = pack_name(pack)
    version = cfg.get("version", "")
    author = cfg.get("author", "")
    description = cfg.get("description", "")
    if not isinstance(version, str):
        version = str(version)
    if not isinstance(author, str):
        author = str(author)
    if not isinstance(description, str):
        description = str(description)
    return {
        "folder": pack,
        "name": name,
        "version": version.strip(),
        "author": author.strip(),
        "description": description.strip(),
        "verified": sign_is_valid(cfg),
        "sign_state": signature_state(cfg),
        "complete": not missing_icons(pack),
    }


def palette_overrides(pack: str, theme: str) -> dict:
    """Return {PALETTE_KEY: color} overrides for one theme from a pack.

    Honors ``palette.dark`` / ``palette.light`` sub-sections, or a flat
    ``palette:`` map that applies to both themes. Only keys in
    :data:`PALETTE_KEYS` are returned, and only when the value looks like a
    color string.
    """
    if not pack \
            or is_default(pack):  # the built-in Default pack is the stock look
        return {}
    pal = load_config(pack).get("palette")
    if not isinstance(pal, dict):
        return {}
    section = pal.get(theme)
    source = section if isinstance(section, dict) else pal
    overrides = {}
    for key, value in source.items():
        if key in PALETTE_KEYS and isinstance(value, str) and \
                value.strip().startswith("#"):
            overrides[key] = value.strip()
    return overrides


def font_family(pack: str) -> str:
    """Font family a pack requests (from ``font: { family: ... }``), or ''
    when it specifies none (falls back to the app default). When the pack
    ships a font file, prefer its embedded family name over this hint.
    The built-in Default pack always returns ''."""
    if not pack or is_default(pack):
        return ""
    font = load_config(pack).get("font")
    if not isinstance(font, dict):
        return ""
    family = font.get("family")
    if isinstance(family, str) and family.strip():
        return family.strip()
    return ""


def font_file(pack: str) -> str:
    """Path to the font file a pack ships (from ``font: { file: ... }``),
    or '' when it provides none. The path is relative to the pack folder."""
    if not pack or is_default(pack):
        return ""
    folder = pack_folder(pack)
    if not folder:
        return ""
    font = load_config(pack).get("font")
    if not isinstance(font, dict):
        return ""
    rel = font.get("file")
    if isinstance(rel, str) and rel.strip():
        candidate = os.path.join(folder, rel.strip())
        if os.path.isfile(candidate):
            return candidate
    return ""


def _ttf_family_from_names(path: str) -> str:
    """Read a TrueType/OpenType font's family name from its ``name`` table.
    Returns '' if it can't be determined (not a TTF/OTF, or no name table).
    This lets a pack ship a font file without the author hard-coding the
    internal family name."""
    try:
        with open(path, "rb") as f:
            data = f.read()
        if len(data) < 12:
            return ""
        num_tables = int.from_bytes(data[4:6], "big")
        name_off = None
        name_len = 0
        for i in range(num_tables):
            pos = 12 + i * 16
            if pos + 16 > len(data):
                break
            tag = data[pos:pos + 4]
            off = int.from_bytes(data[pos + 8:pos + 12], "big")
            length = int.from_bytes(data[pos + 12:pos + 16], "big")
            if tag == b"name":
                name_off, name_len = off, length
                break
        if name_off is None or name_off + name_len > len(data):
            return ""
        nt = data[name_off:name_off + name_len]
        if len(nt) < 6:
            return ""
        count = int.from_bytes(nt[2:4], "big")
        str_base = name_off + int.from_bytes(nt[4:6], "big")
        # Prefer a platform-3 (Windows) / nameID 1 (family) record; fall back
        # to nameID 16 (typographic family) which also lives on Win/mac.
        best = ""
        for i in range(count):
            rec = 6 + i * 12
            if rec + 12 > len(nt):
                break
            platform = int.from_bytes(nt[rec:rec + 2], "big")
            name_id = int.from_bytes(nt[rec + 6:rec + 8], "big")
            length = int.from_bytes(nt[rec + 8:rec + 10], "big")
            offset = int.from_bytes(nt[rec + 10:rec + 12], "big")
            start = str_base + offset
            if start + length > len(data):
                continue
            raw = data[start:start + length]
            if name_id in (1, 16) and platform in (0, 3):
                text = raw.decode("utf-16-be", errors="ignore")
                text = text.replace("\x00", "").strip()
                if not text:
                    continue
                if name_id == 16:
                    return text  # typographic family is the most specific
                best = best or text
        return best
    except Exception:
        return ""


def ttf_family(path: str) -> str:
    """Best-effort family name for a font file on disk ('' if unknown)."""
    try:
        return _ttf_family_from_names(path)
    except Exception:
        return ""


# --------------------------------------------------------------------------
# Pack repository (download packs from a hosted manifest)
# --------------------------------------------------------------------------

def fetch_pack_index(url: str = PACKS_INDEX_URL,
                     timeout: int = updater.DEFAULT_TIMEOUT) -> list:
    """Fetch the pack-repo manifest (a JSON list of packs) from ``url``.

    Returns a list of dicts with at least ``name`` and ``url`` (a download
    link that yields a zip containing the pack). Raises an exception on
    network/manifest errors, or raises :class:`ValueError` for a malformed
    payload.
    """
    if not (url or "").strip():
        return []
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8-sig"))
    except Exception as exc:
        raise updater.UpdateError(f"Could not fetch the pack list: {exc}")
    if isinstance(data, dict):
        data = data.get("packs", [])
    if not isinstance(data, list):
        raise updater.UpdateError(
            "Pack repository must be a JSON list (or {'packs': [...]}).")
    packs = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        name = entry.get("name") or ""
        if not name or not (entry.get("url") or ""):
            continue
        packs.append({
            "name": str(name),
            "url": str(entry["url"]),
            "version": str(entry.get("version", "") or ""),
            "author": str(entry.get("author", "") or ""),
            "description": str(entry.get("description", "") or ""),
        })
    return packs


def install_pack_zip(zip_path: str) -> str:
    """Extract a downloaded pack zip into the Resource Packs folder.

    A pack zip is expected to contain a single CONFIG.yaml. Returns the folder
    name of the installed pack (the top-level folder that ends up holding the
    CONFIG.yaml). Raises :class:`ValueError` if the zip isn't a valid pack.
    """
    import shutil

    if not os.path.isfile(zip_path):
        raise ValueError("Downloaded pack file is missing.")
    try:
        with zipfile.ZipFile(zip_path) as zf:
            names = [n.replace("\\", "/") for n in zf.namelist()]
    except zipfile.BadZipFile as exc:
        raise ValueError(f"Downloaded pack is not a valid zip: {exc}")

    # Locate the config member (CONFIG.yaml or CONFIG.smcs) and the pack
    # folder name we install under.
    config_member = None
    for name in names:
        if os.path.basename(name) in (CONFIG_NAME, CONFIG_SMCS) \
                and not name.endswith("/"):
            config_member = name
            break
    if config_member is None:
        raise ValueError("The zip has no CONFIG.yaml/CONFIG.smcs — not a resource pack.")

    # Pack folder name: use the immediate parent dir of CONFIG.yaml when it is
    # nested, else derive one from the manifest/filename.
    parent = os.path.dirname(config_member)
    if parent and parent != ".":
        pack_name = os.path.basename(parent)
    else:
        pack_name = os.path.basename(os.path.dirname(zip_path)) or "Pack"

    target = packs_dir()
    os.makedirs(target, exist_ok=True)
    prefix = (parent + "/") if parent and parent != "." else ""
    dest_root = os.path.join(target, pack_name)
    os.makedirs(dest_root, exist_ok=True)

    installed = False
    with zipfile.ZipFile(zip_path) as zf:
        for name in names:
            if name.endswith("/"):
                continue
            if not name.startswith(prefix):
                continue
            rel = name[len(prefix):]
            if rel == "" or os.path.basename(rel) in ("pack_info.json", "__MACOSX", SMRP_META_NAME):
                continue
            _, ext = os.path.splitext(rel)
            dest = os.path.join(dest_root, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with zf.open(name) as src, open(dest, "wb") as dst:
                shutil.copyfileobj(src, dst)
            installed = True
    if not installed:
        raise ValueError("Nothing was extracted from the pack zip.")
    return pack_name


def font_size_ratio(pack: str) -> float:
    """Optional size multiplier from ``font: { size: 1.15 }`` (default 1.0)."""
    if not pack or is_default(pack):
        return 1.0
    font = load_config(pack).get("font")
    if isinstance(font, dict):
        size = font.get("size")
        if isinstance(size, (int, float)) and size > 0:
            return float(size)
    return 1.0


def resolved_family(pack: str) -> str:
    """The family name a pack would actually render in: its bundled font
    file's embedded name, else its ``font.family`` hint, else '' (stock)."""
    if not pack or is_default(pack):
        return ""
    rel = font_file(pack)
    if rel:
        embedded = ttf_family(rel)
        if embedded:
            return embedded
    return font_family(pack)


def icon_path(pack: str, icon_name: str, theme: str) -> str:
    """Path to a pack's icon texture for a theme, or '' if the pack has none.

    Dark mode looks for ``<pack>/<icon>.png``; light mode first checks
    ``<pack>/light/<icon>.png`` and falls back to ``<pack>/<icon>.png`` so a
    pack can ship a single set that works in both themes.
    """
    folder = pack_folder(pack)
    if not folder:
        return ""
    candidates = []
    if theme == "light":
        candidates.append(os.path.join(folder, "light", icon_name + ".png"))
    candidates.append(os.path.join(folder, icon_name + ".png"))
    for candidate in candidates:
        if os.path.isfile(candidate):
            return candidate
    return ""


def app_icon_paths(pack: str) -> tuple:
    """(ico_path, png_path) a pack provides for the window icon, or ('', '')."""
    folder = pack_folder(pack)
    if not folder:
        return "", ""
    ico = os.path.join(folder, "icon.ico")
    png = os.path.join(folder, "icon.png")
    return (ico if os.path.isfile(ico) else "",
            png if os.path.isfile(png) else "")


def missing_icons(pack: str) -> list:
    """    Names of icons a pack is missing (dark set, window icons, and the
    light-mode set). A pack is "complete" when this returns an empty list.
    Missing icons simply fall back to the app's built-in textures, so a
    partial pack still works — this is just a completeness report. The built-in
    Default pack always reports as complete."""
    if is_default(pack):
        return []
    folder = pack_folder(pack)
    if not folder:
        return list(ICON_NAMES) + list(INFRA_ICONS)
    missing = []
    for name in ICON_NAMES:
        if not os.path.isfile(os.path.join(folder, name + ".png")):
            missing.append(name + ".png")
    for name in INFRA_ICONS:
        if not os.path.isfile(os.path.join(folder, name)):
            missing.append(name)
    # Light-mode variants (only reported when the dark set is present).
    light_dir = os.path.join(folder, "light")
    for name in ICON_NAMES:
        if not os.path.isfile(os.path.join(light_dir, name + ".png")):
            missing.append("light/" + name + ".png")
    return missing


# --------------------------------------------------------------------------
# Signature CLI helper
# --------------------------------------------------------------------------

def _cli_sign(args: list) -> int:
    """Print a signature a pack author can paste into CONFIG.yaml.

    Usage:
        python -m CORE_FILES.resource_packs --sign NAME VERSION AUTHOR DESC
        python -m CORE_FILES.resource_packs --sign-full "My Pack" 1.0 "Me" "desc"
    """
    # The documented ``--sign`` / ``--sign-full`` flags are cosmetic;
    # strip them so the rest of the args are exactly the four fields.
    if args and args[0] in ("--sign", "--sign-full"):
        args = args[1:]
    if len(args) < 4:
        print("Usage:")
        print("  python -m CORE_FILES.resource_packs --sign NAME VERSION AUTHOR DESC")
        print("  (or --sign-full 'My Pack' 1.0 'Me' 'A description')")
        return 2
    name, version, author, desc = args[0], args[1], args[2], " ".join(args[3:])
    print(compute_signature(name, version, author, desc))
    return 0


if __name__ == "__main__":
    import sys as _sys
    raise SystemExit(_cli_sign(_sys.argv[1:]))
