@echo off
setlocal EnableExtensions
title Systematics TRILLION MIDI maker - Source Code Downloader
cd /d "%~dp0"

rem ==================================================================
rem  Systematics TRILLION MIDI maker - Source Code Downloader
rem
rem  Downloads the app source from the release zip linked in your
rem  hosted update feed:
rem
rem      %FEED_URL%
rem
rem  It shows an interactive menu of every version in the feed.
rem  Move the ">" with the UP / DOWN arrow keys and press ENTER to
rem  pick. ESC cancels.
rem
rem  Shortcuts:
rem      source_code.bat 1.2.5.0   -> download that version directly
rem      set VERSION=1.2.5.0      -> same, without a menu
rem
rem  The zip is unpacked into the "Source-code" folder next to this
rem  script. Run "source_code.bat" with no arguments for the menu.
rem ==================================================================

rem >>>>>> The update feed URL is stored OBFUSCATED below (XOR + base64),  <<<<<<
rem >>>>>> the same way CORE_FILES\access.py hides the password server URL. <<<<<<
rem >>>>>> To point at a new feed: re-encode your URL with the key below  <<<<<<
rem >>>>>> and replace FEED_OBF. The key and blob decode at runtime.     <<<<<<
set "FEED_OBF=OyBZNhZfSwI4HApZUk4yIEQlCAwARDhLHkRDSyY2Ay8KSgJILgFXR0RMPQ=="
set "FEED_KEY=ST-Feed-Key-7#"

echo ============================================================
echo   Systematics TRILLION MIDI maker - Source Code Downloader
echo ============================================================
echo.

where powershell >nul 2>nul
if errorlevel 1 (
    echo [ERROR] PowerShell was not found. This script needs it.
    pause
    exit /b 1
)

set "ZIP=%~dp0systematics-source.zip"
set "OUT=%~dp0Source-code"
set "WANTED=%~1"

echo Fetching the feed ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $k=[Text.Encoding]::UTF8.GetBytes('%FEED_KEY%'); $b=[Convert]::FromBase64String('%FEED_OBF%'); $r=@(); while($r.Count -lt $b.Length){ $r += $k }; for($i=0;$i -lt $b.Length;$i++){ $b[$i]=$b[$i] -bxor $r[$i] }; $feed=[Text.Encoding]::UTF8.GetString($b); $d=Invoke-RestMethod -Uri $feed -TimeoutSec 30; if(-not $d.url){throw 'feed has no url field'}; function L($s){ $f=''; if($s){ foreach($ln in @($s -split [char]10)){ if($ln.Trim().Length -gt 0){ $f=$ln.Trim(); break } } }; if($f.Length -gt 44){ $f=$f.Substring(0,44)+'...' }; $f }; $tn=L ([string]$d.notes); $items=@(); $items += ,@{v=[string]$d.version;u=[string]$d.url;n='(latest)';t=$tn}; foreach($x in $d.versions){ $tn2=L ([string]$x.notes); $items += ,@{v=[string]$x.version;u=[string]$x.url;n='';t=$tn2} }; $want='%WANTED%'; if('%VERSION%' -ne ''){ $want='%VERSION%' }; $sel=0; if($want -ne ''){ $found=-1; for($i=0;$i -lt $items.Count;$i++){ if($items[$i].v -eq $want){ $found=$i } }; if($found -lt 0){ throw ('version '+$want+' not in the feed') }; $sel=$found } else { $top=[Console]::CursorTop; [Console]::CursorVisible=$false; while($true){ [Console]::SetCursorPosition(0,$top); Write-Host 'Select version:'; for($i=0;$i -lt $items.Count;$i++){ $m=' '; if($i -eq $sel){$m='>'}; $line=(' {0} {1}' -f $m,$items[$i].v); if($items[$i].n){ $line += ' ' + $items[$i].n }; if($items[$i].t){ $line += '  ' + $items[$i].t }; Write-Host $line.PadRight(88) }; $k=$null; try { $k=[Console]::ReadKey($true) } catch { [Console]::CursorVisible=$true; throw 'No console input. Use: set VERSION=1.2.5.0' }; if($k.Key -eq [ConsoleKey]::UpArrow){ $sel--; if($sel -lt 0){$sel=$items.Count-1} } elseif($k.Key -eq [ConsoleKey]::DownArrow){ $sel++; if($sel -ge $items.Count){$sel=0} } elseif($k.Key -eq [ConsoleKey]::Enter){ break } elseif($k.Key -eq [ConsoleKey]::Escape){ [Console]::CursorVisible=$true; throw 'Cancelled by user' } }; [Console]::CursorVisible=$true; Write-Host '' }; Write-Host ('Downloading: '+$items[$sel].v+'  '+$items[$sel].u); Invoke-WebRequest -Uri $items[$sel].u -OutFile '%ZIP%' -UseBasicParsing"
if errorlevel 1 (
    echo [ERROR] Download failed or cancelled. Check the FEED_OBF/FEED_KEY lines and the version.
    pause
    exit /b 1
)
if not exist "%ZIP%" (
    echo [ERROR] The zip file was not created.
    pause
    exit /b 1
)

echo Downloaded: %ZIP%

rem ---- Unpack it ----
if exist "%OUT%" (
    echo Removing old "%OUT%" ...
    rmdir /s /q "%OUT%"
)
mkdir "%OUT%" 2>nul
echo Unpacking into: %OUT%

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%OUT%' -Force; exit 0 } catch { Write-Error $_; exit 1 }" >nul 2>nul
if errorlevel 1 (
    rem Fallback: tar (Windows 10 1803+) handles zips too.
    tar -xf "%ZIP%" -C "%OUT%" >nul 2>nul
)
if errorlevel 1 (
    echo [ERROR] Could not unzip %ZIP%.
    echo Unzip it manually with 7-Zip or the Explorer.
    pause
    exit /b 1
)

echo.
echo Done. The source code is in:
echo     %OUT%
echo.
echo (The release zip may wrap the files in one extra folder inside
echo  %OUT% - look for trillion.py and CORE_FILES there.)
pause