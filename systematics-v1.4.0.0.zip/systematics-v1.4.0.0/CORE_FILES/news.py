"""News, announcements and polls feed for Systematics TRILLION MIDI maker.

The app polls a tiny JSON "feed" hosted on GitHub Pages (or anywhere that
serves plain HTTP/HTTPS) and shows the latest headline in a ticker bar at the
bottom of the window, with a "More News" window listing every article and
every poll.

Feed format::

    {
      "articles": [
        {
          "id": "v1.2.0.0",                       # optional
          "title": "Systematics TRILLION MIDI maker v1.2.0.0",
          "date": "2026-08-17",                   # optional
          "summary": "One short line for the ticker.",
          "body": "Longer text. Separate paragraphs with blank lines.",
          "url": "https://example.com/read-more"  # optional
        }
      ],
      "polls": [
        {
          "id": "favorite-mode",                  # optional (title is used if missing)
          "title": "Which mode do you use?",
          "options": ["Fast mode", "Streamed mode", "Double compression"],
          "multiple": false,                      # optional: allow more than one pick
          "results": [12, 5, 2],                  # optional: static tallies
          "submit_url": "https://your-server.com/vote",    # optional: POST votes here
          "results_url": "https://your-server.com/results" # optional: GET live tallies
        }
      ]
    }

Article rules: only ``title`` is required; ``summary`` falls back to the first
line of ``body`` and vice versa. A bare JSON array of articles is also
accepted.

Poll rules: ``title`` and ``options`` (at least two strings) are required.
Options may also be objects with a ``text`` key. ``multiple`` lets a voter pick
more than one option. ``results`` is an optional list of integers (one per
option) the author publishes.

Fully automatic voting: give a poll a ``submit_url`` (the app POSTs
``{"poll": id, "votes": [0, 2]}`` there when someone votes) and a
``results_url`` (the app GETs ``[12, 5, 2]`` or ``{"votes": [...]}`` to show
live tallies). When a poll leaves those out, the app uses the built-in vote
server (``DEFAULT_POLL_SERVER``) so every poll gets live voting out of the
box; ``results`` is still used as the fallback display when the network is
down.
"""

from __future__ import annotations

import json
import urllib.parse
import urllib.request

DEFAULT_TIMEOUT = 10

# The built-in news feed. Point this at your own hosted news.json to publish
# announcements and polls to everyone running the app.
DEFAULT_NEWS_URL = "https://systematicmidis.github.io/news.json"

# The built-in vote backend (your Cloudflare Worker + Durable Object). Polls
# that don't specify their own submit_url/results_url automatically use these
# endpoints, so you only need to write "title" and "options" in news.json.
DEFAULT_POLL_SERVER = "https://polls.systematic-midis.workers.dev"


class NewsError(Exception):
    """Raised when the news feed can't be fetched or is malformed."""


def _download(url: str, timeout: int):
    """Fetch the feed URL and return the decoded JSON document."""
    url = (url or "").strip()
    if not url:
        return {}
    if not (url.startswith("http://") or url.startswith("https://")):
        raise NewsError("News URL must start with http:// or https://")
    request = urllib.request.Request(
        url, headers={"User-Agent": "Systematics-TRILLION-MIDI-maker"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        return json.loads(raw)
    except NewsError:
        raise
    except Exception as exc:
        raise NewsError(f"Could not fetch the news feed: {exc}") from exc


def fetch_feed(url: str = DEFAULT_NEWS_URL, timeout: int = DEFAULT_TIMEOUT) -> dict:
    """Download and parse the feed, returning ``{"articles": [...], "polls": [...]}``.

    Raises :class:`NewsError` when the feed can't be fetched or is malformed.
    """
    data = _download(url, timeout)
    if isinstance(data, list):
        data = {"articles": data}
    if not isinstance(data, dict):
        raise NewsError("News feed must be a JSON object.")
    return {
        "articles": _parse_articles(data.get("articles", data.get("news", []))),
        "polls": _parse_polls(data.get("polls", [])),
    }


def fetch_news(url: str = DEFAULT_NEWS_URL, timeout: int = DEFAULT_TIMEOUT) -> list[dict]:
    """Return just the article list (backward-compatible convenience wrapper)."""
    return fetch_feed(url, timeout)["articles"]


def fetch_polls(url: str = DEFAULT_NEWS_URL, timeout: int = DEFAULT_TIMEOUT) -> list[dict]:
    """Return just the poll list."""
    return fetch_feed(url, timeout)["polls"]


def _parse_articles(items) -> list[dict]:
    if not isinstance(items, list):
        raise NewsError("News feed 'articles' must be a list.")

    articles: list[dict] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title", "")).strip()
        if not title:
            continue
        summary = str(item.get("summary", "")).strip()
        body = str(item.get("body", "")).strip()
        if not body:
            body = summary
        if not summary:
            summary = body.split("\n", 1)[0].strip() if body else title
        if not body:
            body = summary
        articles.append({
            "id": str(item.get("id", "")).strip(),
            "title": title,
            "date": str(item.get("date", "")).strip(),
            "summary": summary,
            "body": body,
            "url": str(item.get("url", "")).strip(),
        })
    return articles


def _parse_polls(items) -> list[dict]:
    if not isinstance(items, list):
        return []

    polls: list[dict] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        title = str(item.get("title", "")).strip()
        if not title:
            continue
        raw_options = item.get("options")
        if not isinstance(raw_options, list):
            continue
        options: list[dict] = []
        for opt in raw_options:
            if isinstance(opt, str):
                text = opt.strip()
            elif isinstance(opt, dict):
                text = str(opt.get("text", opt.get("label", ""))).strip()
            else:
                text = ""
            if text:
                options.append({"text": text})
        if len(options) < 2:
            continue
        results = item.get("results")
        if isinstance(results, list):
            results = [int(r) for r in results if isinstance(r, (int, float))]
        else:
            results = []
        submit_url = str(item.get("submit_url", "")).strip()
        results_url = str(item.get("results_url", "")).strip()
        # Polls without explicit endpoints use the built-in vote server.
        if not submit_url:
            submit_url = DEFAULT_POLL_SERVER.rstrip("/") + "/vote"
        if not results_url:
            results_url = DEFAULT_POLL_SERVER.rstrip("/") + "/results"
        polls.append({
            "id": str(item.get("id", "")).strip() or title,
            "title": title,
            "options": options,
            "multiple": bool(item.get("multiple", False)),
            "results": results,
            "submit_url": submit_url,
            "results_url": results_url,
        })
    return polls


def fetch_results(url: str, poll_id: str = "", timeout: int = DEFAULT_TIMEOUT) -> list[int]:
    """GET a poll's results endpoint and return the per-option vote counts.

    When ``poll_id`` is given it is appended as a ``?poll=<id>`` query
    parameter (unless the URL already carries one). The endpoint may return
    either a bare JSON array ``[12, 5, 2]`` or an object with a ``votes``
    list (and optionally ``total``). Raises :class:`NewsError` when the
    request fails or the payload is malformed.
    """
    url = (url or "").strip()
    if not url:
        return []
    if not (url.startswith("http://") or url.startswith("https://")):
        raise NewsError("Results URL must start with http:// or https://")
    if poll_id:
        sep = "&" if "?" in url else "?"
        url += f"{sep}poll={urllib.parse.quote(str(poll_id), safe='')}"
    request = urllib.request.Request(
        url, headers={"User-Agent": "Systematics-TRILLION-MIDI-maker"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
    except Exception as exc:
        raise NewsError(f"Could not fetch poll results: {exc}") from exc
    if isinstance(data, dict):
        votes = data.get("votes", data.get("results", []))
    elif isinstance(data, list):
        votes = data
    else:
        raise NewsError("Poll results must be a JSON array or an object "
                        "with a 'votes' list.")
    if not isinstance(votes, list):
        raise NewsError("Poll results 'votes' must be a list of numbers.")
    return [int(v) for v in votes if isinstance(v, (int, float))]


def submit_vote(url: str, poll_id: str, votes: list, timeout: int = DEFAULT_TIMEOUT) -> None:
    """POST a vote to a poll's submission endpoint.

    The body is ``{"poll": <id>, "votes": [0, 2]}`` with a JSON content
    type. Raises :class:`NewsError` when the request fails.
    """
    url = (url or "").strip()
    if not url:
        return
    if not (url.startswith("http://") or url.startswith("https://")):
        raise NewsError("Submit URL must start with http:// or https://")
    payload = json.dumps({
        "poll": str(poll_id),
        "votes": [int(v) for v in votes],
    }).encode("utf-8")
    request = urllib.request.Request(
        url, data=payload, method="POST",
        headers={"Content-Type": "application/json",
                 "User-Agent": "Systematics-TRILLION-MIDI-maker"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            resp.read()
    except Exception as exc:
        raise NewsError(f"Could not submit vote: {exc}") from exc
