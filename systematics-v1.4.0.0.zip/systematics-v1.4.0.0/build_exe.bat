@echo off
setlocal EnableExtensions
title Systematics TRILLION MIDI maker - EXE Builder
cd /d "%~dp0"

rem ==================================================================
rem  Systematics TRILLION MIDI maker - EXE Builder
rem
rem  Builds the app into a single EXE with PyInstaller:
rem
rem      dist\Systematics TRILLION MIDI maker.exe
rem
rem  BUILD SOURCE
rem  ------------
rem  local  = build straight from the folder this script is in
rem           (no download, no cleanup). Default choice.
rem
rem  github = download trillion.py + CORE_FILES from the feed's source
rem           zip into a TEMPORARY folder, build the EXE from there,
rem           then DELETE the downloaded files. Only the finished EXE
rem           stays (in dist\). Nothing is changed on GitHub itself.
rem
rem  When you run the script you get an arrow-key menu to pick which
rem  one. Shortcuts:
rem      build_exe.bat local      - build from this folder
rem      build_exe.bat github     - download + build + clean up
rem      set SOURCE_MODE=local    - same, via env var
rem
rem  NOTE: a batch file can NOT remove files from your GitHub repo.
rem  That would need a git push (or a GitHub API token) and it would
rem  break every future download. So "remove the downloaded files"
rem  means: clean up the local copies after the build.
rem ==================================================================

rem >>>>>> The update feed URL is stored OBFUSCATED below (XOR + base64),  <<<<<<
rem >>>>>> the same way CORE_FILES\access.py hides the password server URL. <<<<<<
rem >>>>>> To point at a new feed: re-encode your URL with the key below  <<<<<<
rem >>>>>> and replace FEED_OBF. The key and blob decode at runtime.     <<<<<<
set "FEED_OBF=OyBZNhZfSwI4HApZUk4yIEQlCAwARDhLHkRDSyY2Ay8KSgJILgFXR0RMPQ=="
set "FEED_KEY=ST-Feed-Key-7#"
rem >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
rem >>>>>> BUILD SOURCE: local (this folder) or github (download + clean up)  <<<<<<
rem >>>>>> Pick with an arrow-key menu, or force it:                       <<<<<<
rem >>>>>>   build_exe.bat local    build_exe.bat github    build_exe.bat nopause <<<<<<
rem >>>>>>   (or set SOURCE_MODE=local / SOURCE_MODE=github before running)  <<<<<<
if /i "%~1"=="local"  set "SOURCE_MODE=local"
if /i "%~1"=="github" set "SOURCE_MODE=github"
set "MODE_FILE=%TEMP%\systematics_mode_%RANDOM%.txt"
if not defined SOURCE_MODE (
    where powershell >nul 2>nul
    if errorlevel 1 (
        echo [WARN] PowerShell not found - defaulting to a LOCAL build.
        set "SOURCE_MODE=local"
    ) else (
        powershell -NoProfile -ExecutionPolicy Bypass -Command ^
          "$items=@(@{m='local';d='Build EXE from the local files in this folder'},@{m='github';d='Download source from the feed, build, then delete the download'}); $sel=0; $top=[Console]::CursorTop; [Console]::CursorVisible=$false; while($true){ [Console]::SetCursorPosition(0,$top); Write-Host 'Select build source:'; for($i=0;$i -lt $items.Count;$i++){ $c=' '; if($i -eq $sel){$c='>'}; Write-Host ((' {0} {1}' -f $c,$items[$i].d).PadRight(84)) }; $k=$null; try{ $k=[Console]::ReadKey($true) }catch{ [Console]::CursorVisible=$true; Write-Host ''; throw 'No console input. Use: build_exe.bat local' }; if($k.Key -eq [ConsoleKey]::UpArrow){ $sel--; if($sel -lt 0){$sel=$items.Count-1} } elseif($k.Key -eq [ConsoleKey]::DownArrow){ $sel++; if($sel -ge $items.Count){$sel=0} } elseif($k.Key -eq [ConsoleKey]::Enter){ break } elseif($k.Key -eq [ConsoleKey]::Escape){ [Console]::CursorVisible=$true; Write-Host ''; throw 'Cancelled by user' } }; [Console]::CursorVisible=$true; Write-Host ''; Set-Content -LiteralPath '%MODE_FILE%' -Value $items[$sel].m"
        set /p SOURCE_MODE=<"%MODE_FILE%"
        del "%MODE_FILE%" 2>nul
        if not defined SOURCE_MODE set "SOURCE_MODE=local"
    )
)
rem >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

echo ============================================================
echo   Systematics TRILLION MIDI maker - EXE Builder
echo   Source: %SOURCE_MODE%
if /i "%SOURCE_MODE%"=="github" echo   Feed:   (hidden)
echo ============================================================
echo.

set "BUILD_RESULT=1"
set "WORK="

rem ---- Find a usable Python interpreter ----
set "PY="
where python >nul 2>nul && set "PY=python"
if not defined PY (
    where py >nul 2>nul && set "PY=py -3"
)
if not defined PY (
    echo [ERROR] Python was not found on your PATH.
    echo Install Python 3 from https://www.python.org/downloads/
    goto :done
)

rem ---- Install PyInstaller if missing ----
%PY% -m PyInstaller --version >nul 2>nul
if errorlevel 1 (
    echo Installing PyInstaller ...
    %PY% -m pip install --disable-pip-version-check pyinstaller
    if errorlevel 1 (
        echo [ERROR] Could not install PyInstaller.
        goto :done
    )
)

rem ---- Build temp folder (keeps PyInstaller's work files out of the project) ----
set "WORK=%TEMP%\systematics_build_%RANDOM%"
mkdir "%WORK%" 2>nul

rem ---- Pick the source folder ----
if /i "%SOURCE_MODE%"=="local" (
    set "SRC=%~dp0"
    echo Building from the local folder: %SRC%
    goto :build
)

rem ================= github mode: download, build, delete =================
set "ZIP=%WORK%\source.zip"
set "EXTRACT=%WORK%\src"

where powershell >nul 2>nul
if errorlevel 1 (
    echo [ERROR] PowerShell was not found. github mode needs it.
    goto :cleanup
)

echo Fetching the update feed ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $k=[Text.Encoding]::UTF8.GetBytes('%FEED_KEY%'); $b=[Convert]::FromBase64String('%FEED_OBF%'); $r=@(); while($r.Count -lt $b.Length){ $r += $k }; for($i=0;$i -lt $b.Length;$i++){ $b[$i]=$b[$i] -bxor $r[$i] }; $feed=[Text.Encoding]::UTF8.GetString($b); $d=Invoke-RestMethod -Uri $feed -TimeoutSec 30; if(-not $d.url){throw 'feed has no url field'}; function L($s){ $f=''; if($s){ foreach($ln in @($s -split [char]10)){ if($ln.Trim().Length -gt 0){ $f=$ln.Trim(); break } } }; if($f.Length -gt 44){ $f=$f.Substring(0,44)+'...' }; $f }; $tn=L ([string]$d.notes); $items=@(); $items += ,@{v=[string]$d.version;u=[string]$d.url;n='(latest)';t=$tn}; foreach($x in $d.versions){ $tn2=L ([string]$x.notes); $items += ,@{v=[string]$x.version;u=[string]$x.url;n='';t=$tn2} }; $want=''; if('%VERSION%' -ne ''){ $want='%VERSION%' }; $sel=0; if($want -ne ''){ $found=-1; for($i=0;$i -lt $items.Count;$i++){ if($items[$i].v -eq $want){ $found=$i } }; if($found -lt 0){ throw ('version '+$want+' not in the feed') }; $sel=$found } else { $top=[Console]::CursorTop; [Console]::CursorVisible=$false; while($true){ [Console]::SetCursorPosition(0,$top); Write-Host 'Select version:'; for($i=0;$i -lt $items.Count;$i++){ $m=' '; if($i -eq $sel){$m='>'}; $line=(' {0} {1}' -f $m,$items[$i].v); if($items[$i].n){ $line += ' ' + $items[$i].n }; if($items[$i].t){ $line += '  ' + $items[$i].t }; Write-Host $line.PadRight(88) }; $k=$null; try { $k=[Console]::ReadKey($true) } catch { [Console]::CursorVisible=$true; throw 'No console input. Use: set VERSION=1.2.5.0' }; if($k.Key -eq [ConsoleKey]::UpArrow){ $sel--; if($sel -lt 0){$sel=$items.Count-1} } elseif($k.Key -eq [ConsoleKey]::DownArrow){ $sel++; if($sel -ge $items.Count){$sel=0} } elseif($k.Key -eq [ConsoleKey]::Enter){ break } elseif($k.Key -eq [ConsoleKey]::Escape){ [Console]::CursorVisible=$true; throw 'Cancelled by user' } }; [Console]::CursorVisible=$true; Write-Host '' }; Write-Host ('Downloading: '+$items[$sel].v+'  '+$items[$sel].u); Invoke-WebRequest -Uri $items[$sel].u -OutFile '%ZIP%' -UseBasicParsing"
if errorlevel 1 (
    echo [ERROR] Download failed or cancelled. Check the FEED_OBF/FEED_KEY lines at the top of this file.
    goto :cleanup
)
if not exist "%ZIP%" (
    echo [ERROR] The zip file was not created.
    goto :cleanup
)

echo Unpacking ...
mkdir "%EXTRACT%" 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "try { Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%EXTRACT%' -Force; exit 0 } catch { Write-Error $_; exit 1 }" >nul 2>nul
if errorlevel 1 (
    rem Fallback: tar (Windows 10 1803+) handles zips too.
    tar -xf "%ZIP%" -C "%EXTRACT%" >nul 2>nul
)
if errorlevel 1 (
    echo [ERROR] Could not unzip the downloaded source.
    goto :cleanup
)

rem Locate the folder that actually contains trillion.py.
rem (A trailing backslash on SRC is important - it is used to build
rem  absolute paths like "%SRC%CORE_FILES\assets" for PyInstaller.)
set "SRC="
if exist "%EXTRACT%\trillion.py" set "SRC=%EXTRACT%\"
if not defined SRC (
    for /d %%D in ("%EXTRACT%\*") do (
        if exist "%%D\trillion.py" set "SRC=%%D\"
    )
)
if not defined SRC (
    echo [ERROR] The downloaded zip has no trillion.py + CORE_FILES folder.
    echo The feed's "url" does not point at the app source. Check FEED_URL.
    goto :cleanup
)
echo Building from the downloaded source: %SRC%
goto :build

rem ============================ build step ============================
:build
cd /d "%SRC%"

%PY% -m PyInstaller ^
    --onefile ^
    --clean ^
    --noconfirm ^
    --name "Systematics TRILLION MIDI maker" ^
    --icon "%SRC%CORE_FILES\icon.ico" ^
    --distpath "%~dp0dist" ^
    --workpath "%WORK%\pybuild" ^
    --specpath "%WORK%" ^
    --add-data "%SRC%CORE_FILES\assets;CORE_FILES\assets" ^
    --add-data "%SRC%CORE_FILES\lang;CORE_FILES\lang" ^
    --add-data "%SRC%CORE_FILES\icon.png;CORE_FILES" ^
    --add-data "%SRC%CORE_FILES\icon.ico;CORE_FILES" ^
    trillion.py

set "BUILD_RESULT=%errorlevel%"
cd /d "%~dp0"

rem ================== cleanup: delete downloaded files ==================
:cleanup
if defined WORK (
    if exist "%WORK%" (
        echo.
        echo Deleting the downloaded files ...
        rem Retry a few times in case Windows briefly locks the folder
        rem (Defender scan, closing handles) before giving up.
        for /l %%N in (1,1,5) do (
            rmdir /s /q "%WORK%" 2>nul
            if not exist "%WORK%" goto :cleaned
            ping -n 2 127.0.0.1 >nul
        )
        echo [WARN] Could not fully remove "%WORK%" - delete it manually.
    )
)
:cleaned
rem fall through to :done

:done
echo.
if "%BUILD_RESULT%"=="0" (
    echo ============================================================
    echo   Done! Your EXE is here:
    echo(
    echo       dist\Systematics TRILLION MIDI maker.exe
    echo(
if /i "%SOURCE_MODE%"=="local" (
    echo   Built from the local files in this folder.
) else (
    echo   The downloaded source files were removed after building.
)
    echo ============================================================
    rem Refresh the Windows icon cache so Explorer stops showing the
    rem old (feather) icon for the overwritten EXE. Harmless if it fails.
    if exist "%SystemRoot%\System32\ie4uinit.exe" (
        "%SystemRoot%\System32\ie4uinit.exe" -show >nul 2>nul
    )
    echo If the old icon still shows, right-click the EXE -^> "Open with",
    echo or delete %%LocalAppData%%\IconCache.db and restart Explorer.
) else (
    echo [ERROR] The build failed. See the messages above.
)
if /i not "%~1"=="nopause" if /i not "%~2"=="nopause" pause
endlocal